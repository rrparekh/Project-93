import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import WelcomeScreen from './Screens/WelcomeScreen';
import MealChoice from './Screens/MealChoice';
import IngredientScreen from './Screens/IngredientScreen';
import { createAppContainer, createSwitchNavigator} from 'react-navigation';

export default function App() {
  return (
    <View>
   <AppContainer/>
   </View>
  );
}

var AppNavigator = createSwitchNavigator({
 HomeScreen:WelcomeScreen,
  MealChoice : MealChoice,
  IngredientScreen: IngredientScreen,
})

const AppContainer = createAppContainer(AppNavigator)

