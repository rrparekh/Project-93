import React, { Component } from "react";
import {
  View,
  Text,
  TextInput,
  Image,
  Modal,
  KeyboardAvoidingView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView
} from "react-native";


export default class MealChoice extends Component {

render(){
  return(
    <View>

     <TouchableOpacity
       style={[styles.button, {
          backgroundColor: 'red' }]}
          onPress={() => {
          this.props.navigation.navigate('IngredientScreen')
          }}
          >
          <Text style={styles.buttonText}>𝔹𝕣𝕖𝕒𝕜𝕗𝕒𝕤𝕥</Text>

        </TouchableOpacity>
        

        <TouchableOpacity
       style={[styles.button, {
          backgroundColor: 'pink' }]}
          onPress={() => {
          this.props.navigation.navigate('IngredientScreen')
          }}
          >
          <Text style={styles.buttonText}>𝕃𝕦𝕟𝕔𝕙</Text>

        </TouchableOpacity>

        <TouchableOpacity
       style={[styles.button, {
          backgroundColor: 'teal' }]}
          onPress={() => {
          this.props.navigation.navigate('IngredientScreen')
          }}
          >
          <Text style={styles.buttonText}>𝔻𝕚𝕟𝕟𝕖𝕣</Text>

        </TouchableOpacity>

        <TouchableOpacity
       style={[styles.button, {
          backgroundColor: 'purple' }]}onPress={() => {
          this.props.navigation.navigate('IngredientScreen')
          }}
          >
          <Text style={styles.buttonText}>𝔻𝕖𝕤𝕤𝕖𝕣𝕥</Text>

        </TouchableOpacity>
    </View>
  )
} 
      }

      









const styles = StyleSheet.create({

  button: {
    justifyContent: 'center',
    alignSelf: 'center',
    borderWidth: 2,
    borderRadius: 15,
    marginTop: 100,
    width: 200,
    height: 50,
    bold:30,
  },
   buttonText: {
    textAlign: 'center',
    marginTop: 10,
    color: 'white',

  },
});

  




