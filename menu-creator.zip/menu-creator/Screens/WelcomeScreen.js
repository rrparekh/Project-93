import React, { Component } from "react";
import {
  View,
  Text,
  TextInput,
  Image,
  Modal,
  KeyboardAvoidingView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView
} from "react-native";


export default class WelcomeScreen extends Component {

render(){
  return(
    <View>
    <Text style={styles.Textstyle}> 𝓦𝓮𝓵𝓬𝓸𝓶𝓮 𝓣𝓸 𝓜𝓮𝓷𝓾 𝓒𝓻𝓮𝓪𝓽𝓸𝓻. 𝓟𝓵𝓮𝓪𝓼𝓮 𝓒𝓵𝓲𝓬𝓴 𝓑𝓮𝓵𝓸𝔀 𝓣𝓸 𝓑𝓮𝓰𝓲𝓷 </Text>

<TouchableOpacity>
<Text style={styles.buttonText}  
onPress={() => {
              this.props.navigation.navigate("MealChoice")
               }}> 
               𝙎𝙩𝙖𝙧𝙩 </Text>

        

        </TouchableOpacity>

   <Image
          style={styles.imageIcon}
        source={require('../assets/Meal.png')}
      />
  



  </View>
  
  )

}
}
const styles = StyleSheet.create({
  imageIcon: {
    width: 375,
    height: 800,
    marginLeft: 0,
    borderRadius: 200 / 2,    
    borderWidth: 1,
    borderColor: '#0250a3',
    marginTop:20, 
  },
  Textstyle: {
    marginTop:50,
    textAlign:'center',
  },
   buttonText: {
    textAlign: 'center',
    marginTop: 20,
    color: 'blue',
  },
});

  